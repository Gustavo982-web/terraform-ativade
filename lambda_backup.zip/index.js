// Lambda de backup: cria um snapshot do RDS e exporta para o S3 (Parquet),
// criptografado com KMS. Usa o AWS SDK v3 (ja disponivel no runtime nodejs20.x).
//
// Fluxo:
//   1. Cria um snapshot manual do RDS (CreateDBSnapshot)
//   2. Aguarda o snapshot ficar "available"
//   3. Dispara o export do snapshot para o S3 (StartExportTask)
//
// Variaveis de ambiente (injetadas pelo Terraform):
//   DB_INSTANCE_ID  - identificador da instancia RDS
//   S3_BUCKET       - bucket de destino do export
//   KMS_KEY_ARN     - chave KMS para criptografar o export
//   EXPORT_ROLE_ARN - IAM role que o servico de export assume

const {
  RDSClient,
  CreateDBSnapshotCommand,
  StartExportTaskCommand,
  waitUntilDBSnapshotAvailable,
} = require("@aws-sdk/client-rds");

const rds = new RDSClient({});

exports.handler = async function (event) {
  const dbInstanceId = process.env.DB_INSTANCE_ID;
  const bucket = process.env.S3_BUCKET;
  const kmsKeyArn = process.env.KMS_KEY_ARN;
  const exportRoleArn = process.env.EXPORT_ROLE_ARN;

  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const snapshotId = `cosmos-snap-${stamp}`;
  const exportTaskId = `cosmos-export-${stamp}`;

  try {
    console.log(`[Backup] Criando snapshot ${snapshotId} do RDS ${dbInstanceId}...`);
    await rds.send(
      new CreateDBSnapshotCommand({
        DBInstanceIdentifier: dbInstanceId,
        DBSnapshotIdentifier: snapshotId,
      })
    );

    console.log("[Backup] Aguardando o snapshot ficar disponivel...");
    await waitUntilDBSnapshotAvailable(
      { client: rds, maxWaitTime: 600 },
      { DBSnapshotIdentifier: snapshotId }
    );

    // Monta o ARN do snapshot a partir das variaveis de ambiente
    const region = process.env.AWS_REGION;
    const accountId = process.env.ACCOUNT_ID;
    const snapshotArn = `arn:aws:rds:${region}:${accountId}:snapshot:${snapshotId}`;

    console.log(`[Backup] Iniciando export ${exportTaskId} para s3://${bucket}...`);
    await rds.send(
      new StartExportTaskCommand({
        ExportTaskIdentifier: exportTaskId,
        SourceArn: snapshotArn,
        S3BucketName: bucket,
        S3Prefix: "rds-exports",
        IamRoleArn: exportRoleArn,
        KmsKeyId: kmsKeyArn,
      })
    );

    console.log("[Backup] Export iniciado com sucesso.");
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Backup iniciado com sucesso.",
        snapshot: snapshotId,
        exportTask: exportTaskId,
        destino: `s3://${bucket}/rds-exports/${exportTaskId}`,
      }),
    };
  } catch (error) {
    console.error("[Backup] Erro:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
